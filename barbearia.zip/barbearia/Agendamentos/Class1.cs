﻿namespace Agendamentos;

public class Class1
{

}
