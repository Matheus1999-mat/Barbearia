﻿namespace agendamento
{
    public class Class1
    {

    }
}
