﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//namespace Domain.Servicos.Entities
namespace Domain.Domain
{
    public class Servicos
    {
        public int ServicoID {  get; set; }
        public string NomeServico {  get; set; }
        public string Descricao {  get; set; }
        public int DuracaoMin {  get; set; }
        public float Preco {  get; set; }
        public Agendamentos Agendamentos {  get; set; }
    }
}
