﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Domain
{
    public class Cliente
    {
        public int ClienteID { get; set; }
        public string Nome { get; set; }
        public string Telefone {  get; set; }
        public string Email {  get; set; }
        public DateTime DataNasc {  get; set; }
        //public string Agendamentos {  get; set; }
        public Agendamentos Agendamentos {  get; set; }

    }
}
