﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Agendamentos.Responses
{
    public class AgendamentosResponse
    //internal class AgendamentosResponse
    {
    }
}
