﻿using Application.Agendamentos.Dtos;
using Application.Agendamentos.Responses;
using Application.Servicos.Responses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Agendamentos.Ports
{
    public interface IAgendamentosManager
    {
        Task<object?> CreateAgendamentos(AgendamentosDto agendamentos);
        Task<AgendamentosResponse> GetAgendamentos(int agendamentosDto);
        Task<object?> UpdateAgendamentos(AgendamentosDto agendamentos);
        Task<AgendamentosResponse> DeleteAgendamentos(int agendamentosDto);
        Task<List<AgendamentosResponse>> GetAllAgendamentos();

    }
}
