﻿using Microsoft.Graph;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Application.Agendamentos.Dtos
{
    public class AgendamentosDto
    {
        public int AgendamentoID { get; set; }
        public int ClienteID { get; set; }
        public DateTime DataHora { get; set; }
        public string Observacoes { get; set; }
        public int Status { get; set; }
        //public Servicos Servicos {  get; set; }

    }
}
