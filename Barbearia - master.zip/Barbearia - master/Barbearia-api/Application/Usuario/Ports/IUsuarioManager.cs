﻿using Application.Agendamentos.Dtos;
using Application.Agendamentos.Responses;
using Application.Cliente.Dtos;
using Application.Servicos.Responses;
using Application.Usuario.Responses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Usuario.Ports
{
    public interface IUsuarioManager
    {
        Task<object?> CreateUsuario(UsuarioDto usuario);
        Task<UsuarioResponse> GetUsuario(int usuarioDto);
        Task<UsuarioResponse> DeleteUsuario(int usuarioDto);
        Task<object?> UpdateUsuario(UsuarioDto usuario);
        Task<List<UsuarioResponse>> GetAllUsuarios();
    }
}
