﻿using Application.Cliente.Dtos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Usuario.Responses
{
    //internal class UsuarioResponse
    public class UsuarioResponse
    {
        public UsuarioDto Data;
    }
}
