﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Cliente.Dtos
{
    public class UsuarioDto
    {
        public int UsuarioID { get; set; }
        public string NomeUsuario { get; set; }
        public string Senha { get; set; }
    }
}
