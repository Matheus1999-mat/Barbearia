﻿using Application.Agendamentos.Dtos;
using Application.Agendamentos.Responses;
using Application.Cliente.Dtos;
using Application.Cliente.Responses;
using Application.Servicos.Responses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Cliente.Ports
{
    public interface IClienteManager
    {
        Task<object?> CreateCliente(ClienteDto cliente);
        Task<ClienteResponse> GetCliente(int clienteDto);
        Task<ClienteResponse> DeleteCliente(int clienteDto);
        Task<object?> UpdateCliente(ClienteDto cliente);
        Task<List<ClienteResponse>> GetAllClientes();
    }
}
