﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Cliente.Dtos
{
    public class ServicosDto
    {
        public int ServicoID { get; set; }
        public string NomeServico { get; set; }
        public string Descricao { get; set; }
        public int DuracaoMin { get; set; }
        public float Preco { get; set; }
        //public Agendamentos Agendamentos { get; set; }
    }
}
