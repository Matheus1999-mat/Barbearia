﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Usuario.Ports
{
    public interface IUsuarioRepository
    {
        Task<Domain.Usuario> Get(int UsuarioID);
        Task<Domain.Usuario> Delete(int UsuarioID);
        Task<int> Create(Domain.Usuario usuario);
        Task<int> Update(Domain.Usuario usuario);
        Task<List<Domain.Usuario>> GetAll();
    }
}
