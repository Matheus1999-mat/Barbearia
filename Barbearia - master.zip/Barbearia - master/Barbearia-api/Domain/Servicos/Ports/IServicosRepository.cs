﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Servicos.Ports
{
    public interface IServicosRepository
    {
        Task<Domain.Servicos> Get(int ServicoID);
        Task<Domain.Servicos> Delete(int ServicoID);
        Task<int> Create(Domain.Servicos servicos);
        Task<int> Update(Domain.Servicos servicos);
        Task<List<Domain.Servicos>> GetAll();
    }
}
