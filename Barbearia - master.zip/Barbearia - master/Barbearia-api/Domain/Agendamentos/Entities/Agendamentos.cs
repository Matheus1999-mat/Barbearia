﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Domain
{
    public class Agendamentos
    {
        public int AgendamentoID { get; set; }
        public int ClienteID {  get; set; }
        public DateTime DataHora {  get; set; }
        public string Observacoes {get; set; }
        public int Status {  get; set; }
        public Servicos Servicos {  get; set; }

    }
}
