﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Agendamentos.Ports
{
    public interface IAgendamentosRepository
    {
        Task<Domain.Agendamentos> Get(int AgendamentoID);
        Task<Domain.Agendamentos> Delete(int AgendamentoID);
        Task<int> Create(Domain.Agendamentos agendamentos);
        Task<int> Update(Domain.Agendamentos agendamentos);
        Task<List<Domain.Agendamentos>> GetAll();
    }
}
