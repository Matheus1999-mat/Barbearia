﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Cliente.Ports
{
    public interface IClienteRepository
    {
        Task<Domain.Cliente> Get(int ClienteID);
        Task<Domain.Cliente> Delete(int ClienteID);
        Task<int> Create(Domain.Cliente cliente);
        Task<int> Update(Domain.Cliente cliente);
        Task<List<Domain.Cliente>> GetAll();
    }
}
