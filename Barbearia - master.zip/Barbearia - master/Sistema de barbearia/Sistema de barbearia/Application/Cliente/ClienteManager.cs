﻿using System;
using Application.Agendamentos.Dtos;
using Application.Agendamentos.Responses;
using Application.Cliente.Dtos;
using Application.Cliente.Ports;
using Application.Cliente.Responses;
using Domain.Agendamentos.Exceptions;
using Domain.Agendamentos.Ports;
using Domain.Cliente.Ports;
using Sistema_de_barbearia.Application.Agendamentos.Ports;
using Sistema_de_barbearia.Domain.Agendamentos.Entities;

namespace Sistema_de_barbearia.Application.Cliente
{
    public class ClienteManager : IClienteManager
    {
        private IClienteRepository _clienteRepository;
        public ClienteManager(IClienteRepository clienteRepository)
        {
            _clienteRepository = clienteRepository;

        }

       

        public async Task<Object> CreateCliente(ClienteResponse response)
        {
            try
            {
                var cliente = ClienteDto.MapToEntity(response.Data);
                //response.Data.AgendamentoID = await _agendamentosRepository.Create(agendamentos);
                await cliente.Save(_clienteRepository);
                response.Data.ClienteID = cliente.ClienteID;
                return new ClienteResponse
                {
                    
                    //agendamentos = response.Data,
                    Success = true
                };
            }
            catch (MissingRequiredInformation)
            {
                return new ClienteResponse
                {
                    Success = false,
                    ErrorCodes = ErrorCodes.MISSING_REQUIRED_INFORMATION,
                    Message = "Missing passed required information"
                };
            }
            catch (Exception)
            {
                return new ClienteResponse
                {
                    Success = false,
                    ErrorCodes = ErrorCodes.COULD_NOT_STORE_DATA,
                    Message = "There was an error when saving to DB"
                };
            }
            

        }

        public Task<object?> CreateCliente(ClienteDto cliente)
        {
            throw new NotImplementedException();
        }

        

        public Task<ClienteResponse> DeleteCliente(int clienteDto)
        {
            throw new NotImplementedException();
        }

        
        public Task<List<ClienteResponse>> GetAllClientes()
        {
            throw new NotImplementedException();
        }

        public Task<ClienteResponse> GetCliente(int clienteDto)
        {
            throw new NotImplementedException();
        }

        public Task<object?> UpdateCliente(ClienteDto cliente, int clienteDto)
        {
            throw new NotImplementedException();
        }

        
    }
}
