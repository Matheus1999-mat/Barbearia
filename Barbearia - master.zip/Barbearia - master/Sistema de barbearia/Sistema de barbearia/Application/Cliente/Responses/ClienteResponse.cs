﻿using Application.Agendamentos.Dtos;
using Application.Cliente.Dtos;
using Sistema_de_barbearia.Application;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Cliente.Responses
{
    //internal class ClienteResponse
    public class ClienteResponse:Response
    {
        public ClienteDto Data;
    }
}
