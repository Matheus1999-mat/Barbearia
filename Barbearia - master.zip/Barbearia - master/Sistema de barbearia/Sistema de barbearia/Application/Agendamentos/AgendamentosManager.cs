﻿using System;
using Application.Agendamentos.Dtos;
using Application.Agendamentos.Responses;
using Domain.Agendamentos.Exceptions;
using Domain.Agendamentos.Ports;

using Sistema_de_barbearia.Application.Agendamentos.Ports;
using Sistema_de_barbearia.Domain.Agendamentos.Entities;

namespace Sistema_de_barbearia.Application.Agendamentos
{
    public class AgendamentosManager : IAgendamentosManager
    {
        private IAgendamentosRepository _agendamentosRepository;
        public AgendamentosManager(IAgendamentosRepository agendamentosRepository)
        {
            _agendamentosRepository = agendamentosRepository;

        }
        public async Task<Object> CreateAgendamentos(AgendamentosResponse response)
        {
            try
            {
                var agendamentos = AgendamentosDto.MapToEntity(response.Data);
                //response.Data.AgendamentoID = await _agendamentosRepository.Create(agendamentos);
                await agendamentos.Save(_agendamentosRepository);
                response.Data.AgendamentoID = agendamentos.AgendamentoID;
                return new AgendamentosResponse
                {
                    
                    //agendamentos = response.Data,
                    Success = true
                };
            }
            catch (MissingRequiredInformation)
            {
                return new AgendamentosResponse
                {
                    Success = false,
                    ErrorCodes = ErrorCodes.MISSING_REQUIRED_INFORMATION,
                    Message = "Missing passed required information"
                };
            }
            catch (Exception)
            {
                return new AgendamentosResponse
                {
                    Success = false,
                    ErrorCodes = ErrorCodes.COULD_NOT_STORE_DATA,
                    Message = "There was an error when saving to DB"
                };
            }
            

        }



        public Task<AgendamentosResponse> DeleteAgendamentos(int agendamentosDto)
        {
            throw new NotImplementedException();
            //try
            //{
            //    var agendamentoId = response.Data.AgendamentoID;
            //    await _agendamentosRepository.Delete(agendamentoId);

            //    return new AgendamentosResponse
            //    {
            //        Success = true
            //    };
            //}
            //catch (Exception)
            //{
            //    return new AgendamentosResponse
            //    {
            //        Success = false,
            //        ErrorCodes = ErrorCodes.COULD_NOT_DELETE_DATA,
            //        Message = "There was an error when deleting the data from the DB"
            //    };
            //}
        }

        public Task<AgendamentosResponse> GetAgendamentos(int agendamentosDto)
        {
            throw new NotImplementedException();
            //try
            //{
            //    var agendamentoId = agendamentosDto.AgendamentoID; // ou outro identificador
            //    var agendamento = await _agendamentosRepository.GetById(agendamentoId);

            //    return new AgendamentosResponse
            //    {
            //        Success = true,
            //        Data = agendamento // Supondo que você queira retornar os dados do agendamento
            //    };
            //}
            //catch (Exception)
            //{
            //    return new AgendamentosResponse
            //    {
            //        Success = false,
            //        ErrorCodes = ErrorCodes.COULD_NOT_RETRIEVE_DATA,
            //        Message = "There was an error when retrieving data from the DB"
            //    };
            //}
        }

        public Task<List<AgendamentosResponse>> GetAllAgendamentos()
        {
            throw new NotImplementedException();
        }


        

        Task<object?> IAgendamentosManager.CreateAgendamentos(AgendamentosDto agendamentos)
        {
            throw new NotImplementedException();
        }

        Task<object?> IAgendamentosManager.UpdateAgendamentos(AgendamentosDto agendamentos, int agendamentosDto)
        {
            throw new NotImplementedException();
            //try
            //{
            //    var agendamentoAtualizado = AgendamentosDto.MapToEntity(response.Data);
            //    response.Data.AgendamentoID = await _agendamentosRepository.Update(agendamentoAtualizado, agendamentosDto);

            //    return new AgendamentosResponse
            //    {
            //        Success = true
            //    };
            //}
            //catch (Exception)
            //{
            //    return new AgendamentosResponse
            //    {
            //        Success = false,
            //        ErrorCodes = ErrorCodes.COULD_NOT_UPDATE_DATA,
            //        Message = "There was an error when updating the data in the DB"
            //    };
            //}
        }
    }
}
