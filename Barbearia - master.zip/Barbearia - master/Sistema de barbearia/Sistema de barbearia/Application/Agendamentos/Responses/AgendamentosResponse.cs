﻿using Application.Agendamentos.Dtos;
using Sistema_de_barbearia.Application;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Agendamentos.Responses
{
    public class AgendamentosResponse: Response
    //internal class AgendamentosResponse
    {
        public AgendamentosDto Data;
    }
}
