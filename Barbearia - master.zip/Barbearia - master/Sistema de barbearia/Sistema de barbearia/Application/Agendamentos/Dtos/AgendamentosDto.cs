﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Application.Agendamentos.Dtos
{
    public class AgendamentosDto
    {
        public int AgendamentoID { get; set; }
        public int ClienteID { get; set; }
        public DateTime DataHora { get; set; }
        public string Observacoes { get; set; }
        public string Status { get; set; }
        //public Servicos Servicos {  get; set; }
        public static Sistema_de_barbearia.Domain.Agendamentos.Entities.Agendamentos MapToEntity(AgendamentosDto agendamentosDto)
        {

            return new Sistema_de_barbearia.Domain.Agendamentos.Entities.Agendamentos
            {
                AgendamentoID = agendamentosDto.AgendamentoID,
                ClienteID = agendamentosDto.ClienteID,
                DataHora = agendamentosDto.DataHora,
                Observacoes = agendamentosDto.Observacoes,
                Status = agendamentosDto.Status,
                //DocumentId = new Domain.Guest.ValueObjects.PersonId
                //{
                //    IdNumber = guestDto.IdNumber,
                //    DocumentType = (DocumentType)guestDto.IdTypeCode
                //}
            };
        }

    }
}
