﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Servicos.Dtos
{
    public class ServicosDto
    {
        public int ServicoID { get; set; }
        public string NomeServico { get; set; }
        public string Descricao { get; set; }
        public int DuracaoMin { get; set; }
        public float Preco { get; set; }
        //public Agendamentos Agendamentos { get; set; }
        public static Sistema_de_barbearia.Domain.Servicos.Entities.Servicos MapToEntity(ServicosDto servicosDto)
        {

            return new Sistema_de_barbearia.Domain.Servicos.Entities.Servicos
            {
                ServicoID = servicosDto.ServicoID,
                NomeServico = servicosDto.NomeServico,
                Descricao = servicosDto.Descricao,
                DuracaoMin = servicosDto.DuracaoMin,
                Preco = servicosDto.Preco,
                //DocumentId = new Domain.Guest.ValueObjects.PersonId
                //{
                //    IdNumber = guestDto.IdNumber,
                //    DocumentType = (DocumentType)guestDto.IdTypeCode
                //}
            };
        }
    }
}
