﻿using Application.Agendamentos.Dtos;
using Application.Agendamentos.Responses;
using Application.Cliente.Dtos;
using Application.Servicos.Dtos;
using Application.Servicos.Responses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Servicos.Ports
{

    public interface IServicosManager
    {
        Task<object?> CreateServicos(ServicosResponse response);
        Task<object?> CreateServicos(ServicosDto servicos);
        Task<ServicosResponse> GetServicos(int servicosDto);
        Task<ServicosResponse> DeleteServicos(int servicosDto);
        Task<object?> UpdateServicos(ServicosDto servicos, int servicosDto);
        Task<List<ServicosResponse>> GetAllServicos();
    }
}
