﻿using Application.Cliente.Dtos;
using Application.Servicos.Dtos;
using Sistema_de_barbearia.Application;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Servicos.Responses
{
    //internal class ServicosResponse
    public class ServicosResponse:Response
    {
        public ServicosDto Data;
    }
}
