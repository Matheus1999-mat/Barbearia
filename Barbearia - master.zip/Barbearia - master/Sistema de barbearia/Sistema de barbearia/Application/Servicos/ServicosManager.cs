﻿using System;
using System.ComponentModel.Design;
using Application.Agendamentos.Dtos;
using Application.Agendamentos.Responses;
using Application.Cliente.Dtos;
using Application.Cliente.Ports;
using Application.Cliente.Responses;
using Application.Servicos.Dtos;
using Application.Servicos.Ports;
using Application.Servicos.Responses;
using Domain.Agendamentos.Exceptions;
using Domain.Agendamentos.Ports;
using Domain.Cliente.Ports;
using Domain.Servicos.Ports;
using Sistema_de_barbearia.Application.Agendamentos.Ports;
using Sistema_de_barbearia.Domain.Agendamentos.Entities;

namespace Sistema_de_barbearia.Application.Servicos
{
    public class ServicosManager : IServicosManager
    {
        private IServicosRepository _servicosRepository;
        public ServicosManager(IServicosRepository servicosRepository)
        {
            _servicosRepository = servicosRepository;

        }

        

        public async Task<Object> CreateServicos(ServicosResponse response)
        {
            try
            {
                var servicos = ServicosDto.MapToEntity(response.Data);
                
                await servicos.Save(_servicosRepository);
                response.Data.ServicoID = servicos.ServicoID;
                return new ServicosResponse
                {
                    
                    
                    Success = true
                };
            }
            catch (MissingRequiredInformation)
            {
                return new ServicosResponse
                {
                    Success = false,
                    ErrorCodes = ErrorCodes.MISSING_REQUIRED_INFORMATION,
                    Message = "Missing passed required information"
                };
            }
            catch (Exception)
            {
                return new ServicosResponse
                {
                    Success = false,
                    ErrorCodes = ErrorCodes.COULD_NOT_STORE_DATA,
                    Message = "There was an error when saving to DB"
                };
            }
            

        }

        public Task<object?> CreateServicos(ServicosDto servicos)
        {
            throw new NotImplementedException();
        }

        public Task<ServicosResponse> DeleteServicos(int servicosDto)
        {
            throw new NotImplementedException();
        }

        public Task<List<ServicosResponse>> GetAllServicos()
        {
            throw new NotImplementedException();
        }

        public Task<ServicosResponse> GetServicos(int servicosDto)
        {
            throw new NotImplementedException();
        }

        public Task<object?> UpdateServicos(ServicosDto servicos, int servicosDto)
        {
            throw new NotImplementedException();
        }
    }
}
