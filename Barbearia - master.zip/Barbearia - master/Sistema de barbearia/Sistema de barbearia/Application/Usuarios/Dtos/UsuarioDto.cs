﻿using Application.Servicos.Dtos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Usuarios.Dtos
{
    public class UsuarioDto
    {
        public int UsuarioID { get; set; }
        public string NomeUsuario { get; set; }
        public string Senha { get; set; }
        public static Sistema_de_barbearia.Domain.Usuarios.Entities.Usuario MapToEntity(UsuarioDto usuarioDto)
        {

            return new Sistema_de_barbearia.Domain.Usuarios.Entities.Usuario
            {
                UsuarioID = usuarioDto.UsuarioID,
                NomeUsuario = usuarioDto.NomeUsuario,
                Senha = usuarioDto.Senha,
                
            };
        }
    }
}
