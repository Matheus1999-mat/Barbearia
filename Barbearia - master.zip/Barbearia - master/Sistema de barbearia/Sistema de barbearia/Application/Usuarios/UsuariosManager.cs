﻿using System;
using Application.Agendamentos.Dtos;
using Application.Agendamentos.Responses;
using Application.Usuario.Ports;
using Application.Usuario.Responses;
using Application.Usuarios.Dtos;
using Domain.Agendamentos.Exceptions;
using Domain.Agendamentos.Ports;
using Domain.Usuario.Ports;
using Sistema_de_barbearia.Application.Agendamentos.Ports;
using Sistema_de_barbearia.Domain.Agendamentos.Entities;

namespace Sistema_de_barbearia.Application.Usuarios
{
    public class UsuariosManager : IUsuarioManager
    {
        private IUsuarioRepository _usuarioRepository;
        public UsuariosManager(IUsuarioRepository usuarioRepository)
        {
            _usuarioRepository = usuarioRepository;

        }
        public async Task<Object> CreateUsuarios(UsuarioResponse response)
        {
            try
            {
                var usuarios = UsuarioDto.MapToEntity(response.Data);
                
                await usuarios.Save(_usuarioRepository);
                response.Data.UsuarioID = usuarios.UsuarioID;
                return new UsuarioResponse
                {
                    
                    
                    Success = true
                };
            }
            catch (MissingRequiredInformation)
            {
                return new UsuarioResponse
                {
                    Success = false,
                    ErrorCodes = ErrorCodes.MISSING_REQUIRED_INFORMATION,
                    Message = "Missing passed required information"
                };
            }
            catch (Exception)
            {
                return new UsuarioResponse
                {
                    Success = false,
                    ErrorCodes = ErrorCodes.COULD_NOT_STORE_DATA,
                    Message = "There was an error when saving to DB"
                };
            }
            

        }

        public Task<object?> CreateUsuario(UsuarioDto usuario)
        {
            throw new NotImplementedException();
        }

        public Task<UsuarioResponse> DeleteUsuario(int usuarioDto)
        {
            throw new NotImplementedException();
        }

        public Task<List<UsuarioResponse>> GetAllUsuarios()
        {
            throw new NotImplementedException();
        }

        public Task<UsuarioResponse> GetUsuario(int usuarioDto)
        {
            throw new NotImplementedException();
        }

        public Task<object?> UpdateUsuario(UsuarioDto usuario, int usuarioDto)
        {
            throw new NotImplementedException();
        }
    }
}
