﻿using Domain.Agendamentos.Exceptions;
using Domain.Agendamentos.Ports;
using Domain.Cliente.Ports;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sistema_de_barbearia.Domain.Cliente.Entities
{
    public class Cliente
    {
        public int ClienteID { get; set; }
        public string Nome { get; set; }
        public string Telefone { get; set; }
        public string Email { get; set; }
        public DateTime DataNasc { get; set; }
        //public string Agendamentos {  get; set; }
        //public Agendamentos Agendamentos { get; set; }
        public Sistema_de_barbearia.Domain.Agendamentos.Entities.Agendamentos Agendamentos { get; set; }

        private void ValidateState()
        {


            if (string.IsNullOrEmpty(Nome) || string.IsNullOrEmpty(Telefone) || string.IsNullOrEmpty(Email)  
                )
            {
                throw new MissingRequiredInformation();
            }

        }

        public async Task Save(IClienteRepository clienteRepository)
        {
            this.ValidateState();

            if (this.ClienteID == 0)
            {
                this.ClienteID = await clienteRepository.Create(this);
            }
            else
            {
                //await
            }
        }

    }
}
