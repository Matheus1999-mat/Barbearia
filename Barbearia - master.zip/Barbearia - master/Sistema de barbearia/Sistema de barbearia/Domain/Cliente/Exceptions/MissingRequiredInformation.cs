﻿namespace Domain.Cliente.Exceptions
{
    public class MissingRequiredInformation : Exception
    {
    }
}
