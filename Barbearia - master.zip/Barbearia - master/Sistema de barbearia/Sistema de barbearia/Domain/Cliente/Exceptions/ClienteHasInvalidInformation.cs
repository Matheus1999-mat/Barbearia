﻿namespace Domain.Cliente.Exceptions
{
    public class ClienteHasInvalidInformation
    {
    }
}
