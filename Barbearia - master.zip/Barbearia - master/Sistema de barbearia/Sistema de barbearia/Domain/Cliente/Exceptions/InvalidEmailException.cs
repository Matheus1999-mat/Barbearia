﻿namespace Domain.Cliente.Exceptions
{
    public class InvalidEmailException : Exception
    {
    }
}
