﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Cliente.Ports
{
    public interface IClienteRepository
    {
        Task<Sistema_de_barbearia.Domain.Cliente.Entities.Cliente> Get(int ClienteID);
        Task<Sistema_de_barbearia.Domain.Cliente.Entities.Cliente> Delete(int ClienteID);
        Task<int> Create(Sistema_de_barbearia.Domain.Cliente.Entities.Cliente cliente);
        Task<int> Update(Sistema_de_barbearia.Domain.Cliente.Entities.Cliente cliente);
        Task<List<Sistema_de_barbearia.Domain.Cliente.Entities.Cliente>> GetAll();
    }
}
