﻿namespace Domain.Usuarios.Exceptions
{
    public class UsuariosHasInvalidInformation
    {
    }
}
