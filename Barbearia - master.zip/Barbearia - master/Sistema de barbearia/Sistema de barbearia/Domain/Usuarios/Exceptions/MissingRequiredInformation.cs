﻿namespace Domain.Usuarios.Exceptions
{
    public class MissingRequiredInformation : Exception
    {
    }
}
