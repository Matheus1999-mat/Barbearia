﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Usuario.Ports
{
    public interface IUsuarioRepository
    {
        Task<Sistema_de_barbearia.Domain.Usuarios.Entities.Usuario> Get(int UsuarioID);
        Task<Sistema_de_barbearia.Domain.Usuarios.Entities.Usuario> Delete(int UsuarioID);
        Task<int> Create(Sistema_de_barbearia.Domain.Usuarios.Entities.Usuario usuario);
        Task<int> Update(Sistema_de_barbearia.Domain.Usuarios.Entities.Usuario usuario);
        Task<List<Sistema_de_barbearia.Domain.Usuarios.Entities.Usuario>> GetAll();
    }
}
