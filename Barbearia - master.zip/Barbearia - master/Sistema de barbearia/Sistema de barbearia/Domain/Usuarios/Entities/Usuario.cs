﻿using Domain.Agendamentos.Exceptions;
using Domain.Agendamentos.Ports;
using Domain.Usuario.Ports;
using Sistema_de_barbearia.Domain.Cliente.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Sistema_de_barbearia.Domain.Usuarios.Entities
{
    public class Usuario
    {
        public int UsuarioID { get; set; }
        public string NomeUsuario { get; set; }
        public string Senha { get; set; }

        private void ValidateState()
        {


            if (string.IsNullOrEmpty(NomeUsuario) ||
                string.IsNullOrEmpty(Senha))
            {
                throw new MissingRequiredInformation();
            }

        }

        public async Task Save(IUsuarioRepository usuarioRepository)
        {
            this.ValidateState();

            if (this.UsuarioID == 0)
            {
                this.UsuarioID = await usuarioRepository.Create(this);
            }
            else
            {
                //await
            }
        }

    }
}
