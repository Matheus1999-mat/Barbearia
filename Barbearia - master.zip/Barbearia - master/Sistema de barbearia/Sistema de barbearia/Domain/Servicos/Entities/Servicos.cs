﻿using Domain.Agendamentos.Exceptions;
using Domain.Agendamentos.Ports;
using Domain.Servicos.Ports;
using Sistema_de_barbearia.Domain.Cliente.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//namespace Domain.Servicos.Entities
namespace Sistema_de_barbearia.Domain.Servicos.Entities
{
    public class Servicos
    {
        public int ServicoID { get; set; }
        public string NomeServico { get; set; }
        public string Descricao { get; set; }
        public int DuracaoMin { get; set; }
        public float Preco { get; set; }
        public Agendamentos.Entities.Agendamentos Agendamentos { get; set; }

        private void ValidateState()
        {


            if (string.IsNullOrEmpty(NomeServico) || string.IsNullOrEmpty(Descricao) || DuracaoMin.Equals(0) || Preco.Equals(0))
                
            {
                throw new MissingRequiredInformation();
            }

        }

        public async Task Save(IServicosRepository servicosRepository)
        {
            this.ValidateState();

            if (this.ServicoID == 0)
            {
                this.ServicoID = await servicosRepository.Create(this);
            }
            else
            {
                //await
            }
        }
    }
}
