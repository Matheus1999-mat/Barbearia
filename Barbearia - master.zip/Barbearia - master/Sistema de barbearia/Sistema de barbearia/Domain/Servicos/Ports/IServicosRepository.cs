﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Servicos.Ports
{
    public interface IServicosRepository
    {
        Task<Sistema_de_barbearia.Domain.Servicos.Entities.Servicos> Get(int ServicoID);
        Task<Sistema_de_barbearia.Domain.Servicos.Entities.Servicos> Delete(int ServicoID);
        Task<int> Create(Sistema_de_barbearia.Domain.Servicos.Entities.Servicos servicos);
        Task<int> Update(Sistema_de_barbearia.Domain.Servicos.Entities.Servicos servicos);
        Task<List<Sistema_de_barbearia.Domain.Servicos.Entities.Servicos>> GetAll();
    }
}
