﻿namespace Domain.Servicos.Exceptions
{
    public class ServicosHasInvalidInformation
    {
    }
}
