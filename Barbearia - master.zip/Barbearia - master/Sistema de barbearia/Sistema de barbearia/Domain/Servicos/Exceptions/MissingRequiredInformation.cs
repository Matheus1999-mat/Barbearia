﻿namespace Domain.Servicos.Exceptions
{
    public class MissingRequiredInformation : Exception
    {
    }
}
