﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Agendamentos.Ports
{
    public interface IAgendamentosRepository
    {
        Task<Sistema_de_barbearia.Domain.Agendamentos.Entities.Agendamentos> Get(int AgendamentoID);
        Task<Sistema_de_barbearia.Domain.Agendamentos.Entities.Agendamentos> Delete(int AgendamentoID);
        Task<int> Create(Sistema_de_barbearia.Domain.Agendamentos.Entities.Agendamentos agendamentos);
        Task<int> Update(Sistema_de_barbearia.Domain.Agendamentos.Entities.Agendamentos agendamentos, int AgendamentoID);
        Task<List<Sistema_de_barbearia.Domain.Agendamentos.Entities.Agendamentos>> GetAll();
    }
}
