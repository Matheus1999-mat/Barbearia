﻿namespace Domain.Agendamentos.Exceptions
{
    public class MissingRequiredInformation : Exception
    {
    }
}
