﻿using Domain.Agendamentos.Ports;
using Domain.Cliente.Exceptions;
using Microsoft.EntityFrameworkCore.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;

namespace Sistema_de_barbearia.Domain.Agendamentos.Entities
{
    public class Agendamentos
    {
        public int AgendamentoID { get; set; }
        public int ClienteID { get; set; }
        public DateTime DataHora { get; set; }
        public string Observacoes { get; set; }
        public string Status { get; set; }
        //public Sistema_de_barbearia.Domain.Servicos.Entities.Servicos Servicos { get; set; }

        private void ValidateState()
        {
            

            if (ClienteID.Equals(0) ||
                DataHora.Equals(0))
            {
                throw new MissingRequiredInformation();
            }

        }

        public async Task Save(IAgendamentosRepository agendamentosRepository)
        {
            this.ValidateState();

            if (this.AgendamentoID == 0)
            {
                this.AgendamentoID = await agendamentosRepository.Create(this);
            }
            else
            {
                //await
            }
        }

    }
}
