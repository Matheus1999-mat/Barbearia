﻿using Application;
using Application.Agendamentos.Dtos;
using Application.Agendamentos.Responses;
using Application.Cliente.Dtos;
using Application.Cliente.Ports;
using Application.Cliente.Responses;
using Application.Usuario.Ports;
using Application.Usuario.Responses;
using Application.Usuarios.Dtos;
using Microsoft.AspNetCore.Mvc;
using Sistema_de_barbearia.Application;
using Sistema_de_barbearia.Application.Agendamentos.Ports;
using Sistema_de_barbearia.Domain.Agendamentos.Entities;
using System;

namespace API.Controllers
{
	[ApiController]
	[Route("api/usuarios")]
	public class UsuariosController: ControllerBase
	{
		private readonly ILogger<UsuariosController> _logger;
		private readonly IUsuarioManager _usuariosManager;

		public UsuariosController(ILogger<UsuariosController> logger, IUsuarioManager usuarioManager)
		{
			_logger = logger;
            _usuariosManager = usuarioManager;
		}

		[HttpPost]
		public async Task<ActionResult<UsuarioDto>> PostUsuarios(UsuarioDto usuario)
		{
			var request = new UsuarioResponse
			{
				Data = usuario
            };
			var res = await _usuariosManager.CreateUsuario(usuario);

            if (request.Success) return Created("", request.Data);
            if (request.ErrorCodes == ErrorCodes.NOT_FOUND)
            {
                return BadRequest(request);
            }
            else if (request.ErrorCodes == ErrorCodes.MISSING_REQUIRED_INFORMATION)
            {
                return BadRequest(request);
            }
            return Created("", usuario);


        }

		//Obter todos os usuários
        [HttpGet]
        public async Task<ActionResult<IEnumerable<UsuarioDto>>> GetUsuarios()
        {
            //var usuarios = await _usuariosManager.GetAllUsuarios();
            //return Ok(usuarios);
            throw new NotImplementedException();
        }

		//Obter um usuário específico.
        [HttpGet("{id}")]
        public async Task<ActionResult<UsuarioDto>> GetUsuario(int id)
        {
            //var usuario = await _usuariosManager.GetUsuario(id);
            //if (usuario == null)
            //{
            //    return NotFound();
            //}
            //return Ok(usuario);
            throw new NotImplementedException();
        }

        //Atualizar um usuário
        [HttpPut("{id}")]
        public async Task<IActionResult> PutUsuario(UsuarioDto usuario, int id)
        {
            //if (id != usuario.UsuarioID)
            //{
            //    return BadRequest();
            //}

            //await _usuariosManager.UpdateUsuario(usuario,id);
            //return NoContent();
            throw new NotImplementedException();
        }

        //Deletar um usuário
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteUsuario(int id)
        {
            //var result = await _usuariosManager.DeleteUsuario(id);
            //if (result == null)
            //{
            //    return NotFound();
            //}
            //return NoContent();
            throw new NotImplementedException();
        }



    }
}
