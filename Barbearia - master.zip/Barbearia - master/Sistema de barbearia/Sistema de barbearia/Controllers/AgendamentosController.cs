﻿using Application;
using Application.Agendamentos.Dtos;
using Application.Agendamentos.Responses;

using Microsoft.AspNetCore.Mvc;
using Sistema_de_barbearia.Application;
using Sistema_de_barbearia.Application.Agendamentos.Ports;
using Sistema_de_barbearia.Domain.Agendamentos.Entities;
using System;

namespace API.Controllers
{
	[ApiController]
	[Route("api/agendamentos")]
	public class AgendamentosController: ControllerBase
	{
		private readonly ILogger<AgendamentosController> _logger;
		private readonly IAgendamentosManager _agendamentosManager;

		public AgendamentosController(ILogger<AgendamentosController> logger, IAgendamentosManager agendamentosManager)
		{
			_logger = logger;
            _agendamentosManager = agendamentosManager;
		}

		[HttpPost]
		public async Task<ActionResult<AgendamentosDto>> PostAgendamentos(AgendamentosDto agendamentos)
		{
			var request = new AgendamentosResponse
			{
				Data = agendamentos
            };
			var res = await _agendamentosManager.CreateAgendamentos(request);
            
            if (request.Success) return Created("", request.Data);
            if (request.ErrorCodes == ErrorCodes.NOT_FOUND)
            {
                return BadRequest(request);
            }
            else if (request.ErrorCodes == ErrorCodes.MISSING_REQUIRED_INFORMATION)
            {
                return BadRequest(request);
            }



            return Created("", agendamentos);


        }

		//Obter todos os agendamentos
        [HttpGet]
        public async Task<ActionResult<IEnumerable<AgendamentosDto>>> GetAgendamentos()
        {
            //var agendamentos = await _agendamentosManager.GetAllAgendamentos();
            //return Ok(agendamentos);
            throw new NotImplementedException();
        }

		//Obter um agendamento específico.
        [HttpGet("{id}")]
        public async Task<ActionResult<AgendamentosDto>> GetAgendamento(int id)
        {
            //var agendamento = await _agendamentosManager.GetAgendamentos(id);
            //if (agendamento == null)
            //{
            //    return NotFound();
            //}
            //return Ok(agendamento);
            throw new NotImplementedException();
        }

        //Atualizar um agendamento
        [HttpPut("{id}")]
        public async Task<IActionResult> PutAgendamento(AgendamentosDto agendamentosDto, int id)
        {
            //if (id != agendamentosDto.AgendamentoID)
            //{
            //    return BadRequest();
            //}

            //await _agendamentosManager.UpdateAgendamentos(agendamentosDto,id);
            //return NoContent();
            throw new NotImplementedException();
        }

        //Deletar um agendamento
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteAgendamento(int id)
        {
            //var result = await _agendamentosManager.DeleteAgendamentos(id);
            //if (result == null)
            //{
            //    return NotFound();
            //}
            //return NoContent();
            throw new NotImplementedException();
        }



    }
}
