﻿using Application;
using Application.Agendamentos.Dtos;
using Application.Agendamentos.Responses;
using Application.Cliente.Dtos;
using Application.Cliente.Ports;
using Application.Cliente.Responses;
using Application.Servicos.Dtos;
using Application.Servicos.Ports;
using Application.Servicos.Responses;
using Microsoft.AspNetCore.Mvc;
using Sistema_de_barbearia.Application;
using Sistema_de_barbearia.Application.Agendamentos.Ports;
using Sistema_de_barbearia.Domain.Agendamentos.Entities;
using System;

namespace API.Controllers
{
	[ApiController]
	[Route("api/servicos")]
	public class ServicosController: ControllerBase
	{
		private readonly ILogger<ServicosController> _logger;
		private readonly IServicosManager _servicosManager;

		public ServicosController(ILogger<ServicosController> logger, IServicosManager servicosManager)
		{
			_logger = logger;
            _servicosManager = servicosManager;
		}

		[HttpPost]
		public async Task<ActionResult<ServicosDto>> PostServicos(ServicosDto servicos)
		{
			var request = new ServicosResponse
			{
				Data = servicos
            };
			var res = await _servicosManager.CreateServicos(servicos);

            if (request.Success) return Created("", request.Data);
            if (request.ErrorCodes == ErrorCodes.NOT_FOUND)
            {
                return BadRequest(request);
            }
            else if (request.ErrorCodes == ErrorCodes.MISSING_REQUIRED_INFORMATION)
            {
                return BadRequest(request);
            }
            return Created("", servicos);


        }

		//Obter todos os servicos
        [HttpGet]
        public async Task<ActionResult<IEnumerable<ServicosDto>>> GetServicos()
        {
            //var servicos = await _servicosManager.GetAllServicos();
            //return Ok(servicos);
            throw new NotImplementedException();
        }

		//Obter um serviço específico.
        [HttpGet("{id}")]
        public async Task<ActionResult<ServicosDto>> GetServico(int id)
        {
            //var servicos = await _servicosManager.GetServicos(id);
            //if (servicos == null)
            //{
            //    return NotFound();
            //}
            //return Ok(servicos);
            throw new NotImplementedException();
        }

        //Atualizar um serviço
        [HttpPut("{id}")]
        public async Task<IActionResult> PutServicos(ServicosDto servicosDto, int id)
        {
            //if (id != servicosDto.ServicoID)
            //{
            //    return BadRequest();
            //}

            //await _servicosManager.UpdateServicos(servicosDto,id);
            //return NoContent();
            throw new NotImplementedException();
        }

        //Deletar um serviço
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteServico(int id)
        {
            //var result = await _servicosManager.DeleteServicos(id);
            //if (result == null)
            //{
            //    return NotFound();
            //}
            //return NoContent();
            throw new NotImplementedException();
        }



    }
}
