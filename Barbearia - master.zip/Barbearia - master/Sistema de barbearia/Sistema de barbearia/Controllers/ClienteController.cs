﻿using Application;
using Application.Agendamentos.Dtos;
using Application.Agendamentos.Responses;
using Application.Cliente.Dtos;
using Application.Cliente.Ports;
using Application.Cliente.Responses;
using Microsoft.AspNetCore.Mvc;
using Sistema_de_barbearia.Application;
using Sistema_de_barbearia.Application.Agendamentos.Ports;
using Sistema_de_barbearia.Domain.Agendamentos.Entities;
using System;

namespace API.Controllers
{
	[ApiController]
	[Route("api/cliente")]
	public class ClienteController: ControllerBase
	{
		private readonly ILogger<ClienteController> _logger;
		private readonly IClienteManager _clienteManager;

		public ClienteController(ILogger<ClienteController> logger, IClienteManager clienteManager)
		{
			_logger = logger;
            _clienteManager = clienteManager;
		}

		[HttpPost]
		public async Task<ActionResult<ClienteDto>> PostCliente(ClienteDto cliente)
		{
			var request = new ClienteResponse
			{
				Data = cliente
            };
			var res = await _clienteManager.CreateCliente(cliente);

            if (request.Success) return Created("", request.Data);
            if (request.ErrorCodes == ErrorCodes.NOT_FOUND)
            {
                return BadRequest(request);
            }
            else if (request.ErrorCodes == ErrorCodes.MISSING_REQUIRED_INFORMATION)
            {
                return BadRequest(request);
            }
            return Created("", cliente);


        }

		//Obter todos os clientes
        [HttpGet]
        public async Task<ActionResult<IEnumerable<ClienteDto>>> GetClientes()
        {
            //var clientes = await _clienteManager.GetAllClientes();
            //return Ok(clientes);
            throw new NotImplementedException();
        }

		//Obter um cliente específico.
        [HttpGet("{id}")]
        public async Task<ActionResult<ClienteDto>> GetCliente(int id)
        {
            //var cliente = await _clienteManager.GetCliente(id);
            //if (cliente == null)
            //{
            //    return NotFound();
            //}
            //return Ok(cliente);
            throw new NotImplementedException();
        }

        //Atualizar um cliente
        [HttpPut("{id}")]
        public async Task<IActionResult> PutCliente(ClienteDto clienteDto, int id)
        {
            //if (id != clienteDto.ClienteID)
            //{
            //    return BadRequest();
            //}

            //await _clienteManager.UpdateCliente(clienteDto,id);
            //return NoContent();
            throw new NotImplementedException();
        }

        //Deletar um cliente
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteCliente(int id)
        {
            //var result = await _clienteManager.DeleteCliente(id);
            //if (result == null)
            //{
            //    return NotFound();
            //}
            //return NoContent();
            throw new NotImplementedException();
        }



    }
}
