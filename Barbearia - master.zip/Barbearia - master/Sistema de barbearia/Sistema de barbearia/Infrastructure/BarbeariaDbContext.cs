﻿using Microsoft.EntityFrameworkCore;
using Sistema_de_barbearia.Infrastructure.Agendamentos;
using Sistema_de_barbearia.Infrastructure.Cliente;
using Sistema_de_barbearia.Infrastructure.Servicos;
using Sistema_de_barbearia.Infrastructure.Usuarios;

namespace Sistema_de_barbearia.Infrastructure
{
    public class BarbeariaDbContext :DbContext
    {
        public BarbeariaDbContext(DbContextOptions<BarbeariaDbContext> options) : base(options) { }

        public virtual DbSet<Domain.Agendamentos.Entities.Agendamentos> Agendamentos { get; set; }
        public virtual DbSet<Domain.Cliente.Entities.Cliente> Cliente { get; set; }
        public virtual DbSet<Domain.Servicos.Entities.Servicos> Servicos { get; set; }
        public virtual DbSet<Domain.Usuarios.Entities.Usuario> Usuario { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfiguration(new AgendamentosConfiguration());
            modelBuilder.ApplyConfiguration(new ClienteConfiguration());
            modelBuilder.ApplyConfiguration(new ServicosConfiguration());
            modelBuilder.ApplyConfiguration(new UsuariosConfiguration());
        }
    }
}
