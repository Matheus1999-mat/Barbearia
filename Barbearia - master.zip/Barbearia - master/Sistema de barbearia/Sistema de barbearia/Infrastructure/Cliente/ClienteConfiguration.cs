﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Sistema_de_barbearia.Infrastructure.Cliente
{
    public class ClienteConfiguration: IEntityTypeConfiguration<Domain.Cliente.Entities.Cliente>
    {
        public void Configure(EntityTypeBuilder<Domain.Cliente.Entities.Cliente> builder)
        {
            builder.HasKey(e => e.ClienteID);
            builder.Property(e=>e.Nome).IsRequired();
            builder.Property(e => e.Telefone);
            builder.Property(e => e.Email).IsRequired();
            builder.Property(e => e.DataNasc);
            

        }

        
    }
}
