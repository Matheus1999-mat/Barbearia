﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Sistema_de_barbearia.Infrastructure.Servicos
{
    public class ServicosConfiguration: IEntityTypeConfiguration<Domain.Servicos.Entities.Servicos>
    {
        public void Configure(EntityTypeBuilder<Domain.Servicos.Entities.Servicos> builder)
        {
            builder.HasKey(e => e.ServicoID);
            builder.Property(e=>e.NomeServico).IsRequired();
            builder.Property(e => e.Descricao);
            builder.Property(e => e.DuracaoMin);
            builder.Property(e => e.Preco);
            

        }

        
    }
}
