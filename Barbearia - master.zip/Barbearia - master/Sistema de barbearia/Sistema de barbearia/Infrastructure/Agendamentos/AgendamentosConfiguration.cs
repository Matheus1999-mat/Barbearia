﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Sistema_de_barbearia.Infrastructure.Agendamentos
{
    public class AgendamentosConfiguration: IEntityTypeConfiguration<Domain.Agendamentos.Entities.Agendamentos>
    {
        public void Configure(EntityTypeBuilder<Domain.Agendamentos.Entities.Agendamentos> builder)
        {
            builder.HasKey(e => e.AgendamentoID);
            builder.Property(e => e.ClienteID).IsRequired();
            builder.Property(e => e.DataHora);
            builder.Property(e => e.Observacoes);
            builder.Property(e => e.Status);
            builder.HasOne<Domain.Cliente.Entities.Cliente>() // Certifique-se de que o nome da classe está correto
        .WithMany() // Ou .WithOne(), dependendo do seu modelo de dados
        .HasForeignKey(e => e.ClienteID);

        }

        
    }
}
