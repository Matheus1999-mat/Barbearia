﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Sistema_de_barbearia.Infrastructure.Usuarios
{
    public class UsuariosConfiguration: IEntityTypeConfiguration<Domain.Usuarios.Entities.Usuario>
    {
        public void Configure(EntityTypeBuilder<Domain.Usuarios.Entities.Usuario> builder)
        {
            builder.HasKey(e => e.UsuarioID);
            builder.Property(e=>e.NomeUsuario).IsRequired();
            builder.Property(e => e.Senha).IsRequired();
            
            

        }

        
    }
}
